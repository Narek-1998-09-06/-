import registerFormBlock from './FormBlock/registerFormBlock';

registerFormBlock();
