module.exports = {
  extends: ['hubspot-dev/jasmine'],
};
